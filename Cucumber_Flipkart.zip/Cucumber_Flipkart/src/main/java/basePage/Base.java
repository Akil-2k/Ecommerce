package basePage;

import java.io.File;
import java.io.FileInputStream;

import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.google.common.io.Files;

import Utils.ExtentReport;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Base {

	public static Properties property;
	public static WebDriver driver;
	public static Logger log;
	public static ExtentReports reporter =ExtentReport.extentReport();
	public static ExtentTest report;

	public void openBrowser() throws IOException {

		property = new Properties();
		property.load(new FileInputStream("src/main/java/configuration/config.properties"));

		if(property.getProperty("browserName").equalsIgnoreCase("chrome")) {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
		}
		if(property.getProperty("browserName").equalsIgnoreCase("edge")) {
			WebDriverManager.edgedriver().setup();
			driver=new EdgeDriver();
		}

		driver.manage().window().maximize();

		driver.get(property.getProperty("url"));

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

	}
	public void closeBrowser() {
		driver.quit();
		reporter.flush();
	}
	public void testPass(String reporter) {
		report.log(Status.PASS, reporter);
	}
	public void testFail(String reporter) {
		report.log(Status.FAIL, reporter);
	}
	public void passSnap() throws IOException {
	  File passpic = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	  Files.copy(passpic, new File("./snaps/passSnap/pass.png"));
	}
	public void failSnap() throws IOException {
	  File failpic =  ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	  Files.copy(failpic, new File("./snaps/failSnap/fail.png"));
	}
}
