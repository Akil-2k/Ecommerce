package pages;

import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


import basePage.Base;

public class purchasePage extends Base{

	@FindBy(xpath="//input[@class='_3704LK']")
	public static WebElement searchBox;

	@FindBy(xpath="(//div[@class='_2kHMtA'])[1]")//(//div[@class='_2kHMtA'])[1]
	public static WebElement selectProduct;

	@FindBy(xpath="//button[@class='_2KpZ6l _2U9uOA _3v1-ww']")
	public static WebElement addToCart;

	/*
	 * public void purchaseProduct() { PageFactory.initElements(driver, this);
	 * searchBox.sendKeys(" hp laptop i5 11th generation"); searchBox.submit();
	 * selectProduct.click(); addToCart.click();
	 */		
	//}

	public void selectProduct() throws InterruptedException {
		
		report=reporter.createTest("TestStep-04=Select The Product");
		
		PropertyConfigurator.configure("src\\main\\java\\configuration\\log4j.properties");
		Logger log=Logger.getLogger(loginPage.class);
		
		PageFactory.initElements(driver, this);
		searchBox.sendKeys(property.getProperty("productName"));
		searchBox.submit();
		
		log.info("User searched the product");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[1]/div[2]/div[2]/div/div/div")).click();

	}
	public void addTheProduct() {
		
		report=reporter.createTest("TestStep-05=Add The Product To Cart");
		
		PropertyConfigurator.configure("src\\main\\java\\configuration\\log4j.properties");
		Logger log=Logger.getLogger(loginPage.class);
		
		PageFactory.initElements(driver, this);
		ArrayList<String> wid = new ArrayList<String>(driver.getWindowHandles());
        //switch to active tab
        driver.switchTo().window(wid.get(1));  
		addToCart.click();
		
		log.info("User add the product to cart");
	}



}
