package pages;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.excel.lib.util.Xls_Reader;

import basePage.Base;


public class loginPage extends Base {

	@FindBy(xpath="//button[@class='_2KpZ6l _2doB4z']")
	public static WebElement cancelBtn;

	@FindBy(xpath="//a[text()='Login']")
	public static WebElement loginBtn;

	@FindBy(xpath="//input[@class='_2IX_2- VJZDxU']")
	public static WebElement userName;

	@FindBy(xpath="//input[@class='_2IX_2- _3mctLh VJZDxU']")
	public static WebElement password;

	@FindBy(xpath="//button[@class='_2KpZ6l _2HKlqd _3AWRsL']")
	public static WebElement submitBtn;
	
	
	
	 

	//public void loginUser(String userNamee, String passwordd) {
	public void loginUser() {
		report=reporter.createTest("TestStep-01=Login User");
		
		PropertyConfigurator.configure("src\\main\\java\\configuration\\log4j.properties");
		Logger log=Logger.getLogger(loginPage.class);
		
		PageFactory.initElements(driver, this);
		try {
			cancelBtn.click();
			loginBtn.click();
		} catch (Exception e) {
			loginBtn.click();
			
		}
		userName.sendKeys(property.getProperty("userNamee"));
		byte[] decodedString = Base64.decodeBase64(property.getProperty("passwordd"));
		password.sendKeys(new String(decodedString));
		log.info("User entered the valid credentials");
		report.info("User entered the valid credentials");


		//userName.sendKeys(userNamee);
		//password.sendKeys(passwordd);
	}

	public void submitBtn() {
		report=reporter.createTest("TestStep-02=Submit the loginpage");
		
		PropertyConfigurator.configure("src\\main\\java\\configuration\\log4j.properties");
		Logger log=Logger.getLogger(loginPage.class);
		
		PageFactory.initElements(driver, this);	
		submitBtn.click();
		
		log.info("User successfully login the website ");
	}
	
	 public void assertCheck() {
		 
		 report=reporter.createTest("TestStep-03=Assert Verification");
		 
		 PageFactory.initElements(driver, this); 
		 //String  currentUrl; 
	 String currentUrl=driver.getCurrentUrl();
	 String ExpectedUrl ="https://www.flipkart.com/";
	 
	  if (currentUrl.matches(ExpectedUrl)) { 
		  System.out.println("Assert Verified");
	  }else {
		  System.out.println("Assert Failed"); }
	  //Assert.assertEquals(currentUrl, ExpectedUrl); 
	  }
	
	
}
