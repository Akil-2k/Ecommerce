package Utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import basePage.Base;

public class ExtentReport extends Base {

	public static ExtentReports extent;
	
	public static  ExtentReports  extentReport() {
		if(extent==null) {
			ExtentSparkReporter reporter =new ExtentSparkReporter("./Report.html");
			extent = new ExtentReports();
			extent.attachReporter(reporter);
		}
		return extent;
		
	}
}
