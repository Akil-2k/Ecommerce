package stepDefinitions;

import io.cucumber.java.en.Then;
import pages.loginPage;
import pages.purchasePage;

public class ProductOrder {

	loginPage lp = new loginPage();
	purchasePage pp = new purchasePage();
	
	@Then("search the product")
	public void search_the_product() throws InterruptedException {
		pp.selectProduct();
	}

	@Then("add to cart")
	public void add_to_cart() {
		pp.addTheProduct();
	}

	@Then("close the browser")
	public void close_the_browser() {
		lp.closeBrowser();

	}


}
