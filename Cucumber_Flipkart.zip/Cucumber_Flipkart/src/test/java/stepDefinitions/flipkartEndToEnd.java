package stepDefinitions;


import java.io.IOException;


import org.openqa.selenium.WebDriver;


import com.excel.lib.util.Xls_Reader;

import basePage.Base;
import io.cucumber.java.en.*;

import pages.loginPage;
import pages.purchasePage;


public class flipkartEndToEnd extends Base{
	//public static WebDriver driver;

	loginPage lp = new loginPage();
	

	@Given("user is on login page")
	public void user_is_on_login_page() throws IOException {
		lp.openBrowser();
	}

	@When("user enter the username and password")
	public void user_enter_the_username_and_password() {


		lp.loginUser();


	}

	@When("click on login button")
	public void click_on_login_button() {
		lp.submitBtn();

	}
	@Then("the user is navigated to home page")
	public void the_user_is_navigated_to_home_page() {
	lp.assertCheck();

	}

	
}
