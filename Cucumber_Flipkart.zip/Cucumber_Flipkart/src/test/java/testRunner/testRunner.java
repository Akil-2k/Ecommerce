package testRunner;

import org.junit.runner.RunWith;

import basePage.Base;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;


@RunWith(Cucumber.class)
@CucumberOptions(
		features= {"features"},
		dryRun =!true,
		glue= {"stepDefinitions"},
		monochrome = true
	)

public class testRunner extends Base {

	

	

}
